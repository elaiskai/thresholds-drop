OUT OF CONTEXT - Questions Box (artist book)
============================================

Inner dimensions:   160 x 118 x 20 mm
Fits:               30 x A6 cards (105 x 148 mm) + ~1 cm wiggle on each axis
                    Length:  160 - 148 = 12 mm wiggle  (6 mm each end)
                    Width:   118 - 105 = 13 mm wiggle  (6.5 mm each side)
                    Depth:    20 - ~12 = 8 mm lid clearance
Material:           E-flute corrugated cardboard, 1.5 mm
Bleed:              3 mm
Tuck flap:          10 mm (so lid closes flush, no overhang)
Canvas:             A3 portrait (297 x 420 mm), dieline centered

FILES
-----
01-dieline-cut-only.svg   technical sheet (cut/fold/glue/bleed only)
02-dieline-with-art.svg   printable art (cover, spine, page edges)
03-mockup-3d.svg          closed-box preview (looks like a book)

ASSEMBLY
--------
1. Fold lid and bottom panel up at the spine fold.
2. Fold left/right wings up; they form the short side walls.
3. Glue the blue-dashed tabs inside the spine and front wall.
4. Tuck flap drops into the front wall through the thumb notch.
