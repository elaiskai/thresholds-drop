THRESHOLDS  -  Volume I (Questions Box)
========================================

Inner dimensions:   150 x 108 x 15 mm
Material spec:      E-flute corrugated cardboard, 1.5 mm thickness
Bleed:              3 mm on all sides
Tuck flap length:   10 mm  (reduced from 12 mm in earlier draft)

WHAT IS IN THIS ZIP
-------------------
01-dieline-cut-only.svg
    Technical die-cut layout. Cut lines = solid black. Fold/crease lines = red
    dashed. Glue surfaces = blue dashed. Bleed boundary = grey dashed.
    Send this file to the print/cut shop.

02-dieline-with-art.svg
    Full printable artwork laid on the dieline:
      - Aged-parchment background (radial gradient + paper grain pattern)
      - Engraved double border + corner brackets + alchemical flourishes
      - Central medallion (threshold/doorway/eye motif)
      - Title in classical serif (IM Fell English / Cormorant Garamond)
      - Spine = oxblood leather + gilt rules + gilded spine title
      - Three walls (top, bottom, fore-edge) FULLY filled with simulated
        page edges (dense vertical/horizontal lines + chapter dividers
        + warm gilt highlight + depth shadows)
    Open this in Adobe Illustrator. Send the same SVG (or export to PDF
    with bleed) to your printer.

03-mockup-3d.svg
    Quick visual preview of the closed box at 3/4 angle, showing how it
    will read as a real hardcover book on a shelf.

FONT NOTES
----------
The cover text references three open-source serif faces:
  IM Fell English        (Google Fonts)
  Cormorant Garamond     (Google Fonts)
  Trajan Pro             (Adobe Fonts - fallback)
If your Adobe doesn't have IM Fell English installed, fonts will fall
back to Cormorant Garamond then to system serif. Install IM Fell from
fonts.google.com/specimen/IM+Fell+English for the antique-press feel.

For a strictly print-safe deliverable, in Illustrator:
  Type > Create Outlines  (converts all text to vector paths)
  File > Save As  > PDF with X-1a:2001 preset, include 3mm bleed.

ASSEMBLY
--------
After cutting and creasing:
  1. Fold the spine and bottom panel up.
  2. Fold the left and right short walls up.
  3. Apply glue to the small blue-marked tabs on the wing edges.
     Press them against the inside of the spine and front wall.
  4. The tuck flap (10 mm) drops down into the slot inside the front
     wall when you close the lid. Use the thumb notch (small arc cut)
     to lift the lid open again.

VOLUME II (Answers Box)
-----------------------
Use the same dieline. Change only:
  - Title:    A N S W E R S
  - Subtitle: fifty replies without their questions
  - Volume:   . VOLUME . II . OF . II .
  - Spine:    A N S W E R S
  - Back cover subhead: A FIELD GUIDE TO REPLYING
A separate generator run for Vol II is recommended once the questions
box is approved.
